Scilexer.dll    : Scintilla control with lexer.
Scintilla.h     : C include file of Scintilla control.
Scintilla.iface : Interface desciption of Scintilla control.

