This directory contsins code for generating a minimal perfect hash that
is used for fast lookup of constants with a relatively small code
footprint.

The source code in this directory is modified from the original source
taken from http://burtleburtle.net/bob/hash/perfect.html

Modifications were made by Robert May - most of the functionality that
is not required at this time by the Win32::GUI::Constants build
process has been disabled.
