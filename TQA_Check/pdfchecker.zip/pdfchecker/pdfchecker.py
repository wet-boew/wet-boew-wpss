# -- coding: utf-8

#! /usr/bin/env python

#      Copyright 2008-2010 eGovMon
#      This program is distributed under the terms of the GNU General
#      Public License.
#
#  This file is part of the eGovernment Monitoring
#  (eGovMon)
#
#  eGovMon is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  eGovMon is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with eGovMon; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston,
#  MA 02110-1301 USA

""" Command-line PDF accessibility checker """

__author__ = "Anand B Pillai"
__maintainer__ = "Anand B Pillai"
__version__ = "0.1"
__updated__ = "$LastChangedDate$"

import pdfAWAM
import sys, os
import optparse
import time

USAGE="""%s [options] pdffile - Check PDF documents for accessibility"""

def checkAcc(pdffile, passwd='', verbose=True, report=False):
    pdfAWAM.extractAWAMIndicators(open(pdffile,'rb'), passwd, verbose, report)

def setupOptions():
    if len(sys.argv)==1:
        sys.argv.append('-h')
        
    o = optparse.OptionParser(usage=USAGE % sys.argv[0] )
    o.add_option('-p','--password',
                 dest='password',help='Optional password for encrypted PDF',default='')
    o.add_option('-q','--quiet',
                 dest='quiet',help="Be quiet, won't print debug/informational messages",action="store_true",
                 default=False)
    o.add_option('-r','--report',
                 dest='report',help="Print a report of test results at the end",action="store_true",
                 default=False)        

    options, args = o.parse_args()
    return (args[0], options.__dict__)

def main():
    pdffile, options = setupOptions()

    password = options.get('password','')
    quiet = options.get('quiet')
    report = options.get('report')
    
    verbose = (not quiet)
    checkAcc(pdffile, password, verbose, report)

if __name__ == "__main__":
    main()
