# -- coding: utf-8


#      Copyright 2008-2010 eGovMon
#      This program is distributed under the terms of the GNU General
#      Public License.
#
#  This file is part of the eGovernment Monitoring
#  (eGovMon)
#
#  eGovMon is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  eGovMon is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with eGovMon; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston,
#  MA 02110-1301 USA

__author__ = "Anand B. Pillai"
__updated__ = "$LastChangedDate$"
__version__ = "$Id: version.py 1974 2006-04-24 18:35:47Z num $"

""" A simple PDF accessibility checking WAM

Creation: Anand B Pillai <abpillai at gmail dot com> April 27 2007

Modification History

Anand April 27 07   Added more exception handling. Fixed a
                    problem in pyPdf which was not reading
                    certain encrypted PDF docs.
Anand May 24 2009   Added method to determine scanned PDF.
                    Added method to determine # of Images.

"""


from pyPdf import PdfFileReader
from pyPdf.utils import PdfReadError
from pdfAWAMHandler import PdfAWAMHandler
from pdfStructureMixin import PdfStructureMixin
import pdfwcag

import sys 
import time

# The main pdf-wam class containing most of the
# checking logic
pdfklass = pdfwcag.PdfWCAG

class DecryptionFailedException(Exception):
    pass

__author__ = "Anand B Pillai"
__maintainer__ = "Anand B Pillai"
__version__ = "0.1"

class MyPdfFileReader(PdfFileReader, pdfklass):
    """ Our own customized Pdf file reader class
    which inherits from the pyPdf one """
    
    def __init__(self, stream, password=''):
        pdfklass.__init__(self)
        self.flattenedPages = None
        self.resolvedObjects = {}
        # In pdf.py the read happens before the following
        # 2 initializations. But we need to switch the order.
        self.stream = stream
        self._override_encryption = False
        self.passwd = password

    def read(self):
        """ Function which overrides 'read' of PdfFileReader class """

        # PdfFileReader.read2(self, stream)
        PdfFileReader.read(self, self.stream)
        PdfStructureMixin.read(self, self.stream)
        # Decrypt automatically with password
        if self.getIsEncrypted():
            self.echo('Document is encrypted. Trying to decrypt')
            ret = self.decrypt(self.passwd)
            if ret:
                self.echo('Document decryption success.')
            else:
                self.echo('Document decryption failed.')
                raise DecryptionFailedException

        # Fill in document information
        self.fillInfo()
        # Set the root object
        self.root =  self.trailer['/Root'].getObject()
    
def extractAWAMIndicators(pdf, password='', verbose=True, report=False):
    """ Check whether the given PDF document is accessible """

    t = time.time()
    
    # Takes an optional password which can be used to
    # unlock the document for encrypted documents.
    try:
        pdfobj = MyPdfFileReader(pdf, password)
        pdfobj.verbose = verbose
        
        pdfobj.read()
        pdfobj.fixIndirectObjectXref()

        if verbose:
            print "***PDF Summary: Start***"
            print 'Version:',pdfobj.version
            print '#Pages:',pdfobj.numPages
            #print 'Producer:',pdfobj.producer
            #print 'Creator:',pdfobj.creator
            if pdfobj.title:
                # Remove any invalid characters from the title.
                title = pdfobj.title
                print 'Title=>',title.encode("utf8","ignore")
            else:
                print 'Title: (None)'

            print 'Has structure tree:',(pdfobj.structTree != None)
            has_forms = pdfobj.hasForms()
            print 'Has forms:',has_forms
            print 'Has bookmarks:',pdfobj.hasBookmarks()
            print 'Scanned:',pdfobj.isScanned
            print 'Num Images:',pdfobj.getNumImages()

            print '***PDF Summary: End ****\n'
        pdfobj.runAllTests()
    except DecryptionFailedException:
        # We are unable to decrypt document.
        # We have got no parsed pdfobj, and cannot do much more,
        # unfortunately... 
        # Tell that the document was not accessible due to encryption, at least
        errmsg="Document Decryption failed"
        print errmsg
        open('.pdferror','w').write(errmsg)
        # return {'EIAO.A.10.8.1.4.PDF.1.1':{(0, 1): 0}}
        # Ticket 127 fix
        return {}
    except NotImplementedError:
        # pyPdf only supports algorithm version 1 and 2. 
        # Version 3 and 4 are not yet supported.
        errmsg="Unsupported decryption algorithm."
        print errmsg
        open('.pdferror','w').write(errmsg)
        # return {'EIAO.A.10.8.1.4.PDF.1.1':{(0, 1): 0}}
        # Ticket 127 fix        
        return {}
    except PdfReadError, e:
        errmsg='Error, cannot read PDF file: ' + str(e)
        print errmsg
        open('.pdferror','w').write(errmsg)        
        # Not a PDF file
        return {}
    
    print 'Processed in %.2f seconds' % (time.time() - t)
    rmap = pdfobj.awamHandler.resultMap
    print '\n***AWAM Dictionary***'
    #print rmap

    if verbose:
        for id in rmap.keys():
            value = rmap[id]
            if type(value) is dict:
                for location in value.keys():
                    print 'AWAM-ID:',id,' location:',location,' value:',value[location]
            else:
                print 'AWAM-ID:',id,'value:',value
            
    if report:
        pdfobj.print_report()

    return rmap
        

    

